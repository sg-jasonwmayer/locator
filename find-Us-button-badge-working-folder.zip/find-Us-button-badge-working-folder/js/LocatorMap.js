'use strict';

//---------------------------------------
//export const LocatorMap = ( function() {
window.LocatorMap = ( function() {
  let gmap, markerBounds, infoWindow;
  let directionsService, directionsDisplay;
  let markers = [];

  const _private = {
    init: function( geometry ) {
      // Clear previous markers, if any:
      markers.forEach( ( mrk, i ) => _private.unplaceMarker( i ) );
      markers = [];

      // Ensure we have legit map and bounds objects:
      gmap = gmap || ( new google.maps.Map( $( '#map' ).get(0) ) );
      // markerBounds = new google.maps.LatLngBounds();   // start with empty bounds, will expand as we add markers

      if ( geometry ) {    // iff geometry provided, set initial map view
        gmap.fitBounds( geometry.viewport );
      }

      let $autoDirection = $( '#auto-direction' );

      if ( $autoDirection.length ) {        // TODO: find a better way to make this conditional
        directionsService = new google.maps.DirectionsService();
        directionsDisplay = new google.maps.DirectionsRenderer();
        directionsDisplay.setMap( gmap );
        directionsDisplay.setPanel( $autoDirection.get(0) );
      }
    },

    // createMarker: function( lat, lng, label, infoWindowSelector ) {
    createMarker: function( lat, lng, label, $item ) {
      // gmap || _private.init();
      let pos = new google.maps.LatLng( lat, lng );
      let opts = { position: pos };
      label && ( opts.label = { text: label, color: 'white' } );
      let marker = new google.maps.Marker( opts );

      // markerBounds.extend( pos );
      markers.push( marker );
      // marker.setMap( gmap );

      // if ( infoWindowSelector ) {
      if ( $item ) {
        google.maps.event.addListener( marker, 'click', function() {
          // infoWindow && infoWindow.close();
          // infoWindow = new google.maps.InfoWindow( { content: $( infoWindowSelector ).html() } );
          // google.maps.event.addListener( infoWindow, 'closeclick', () => gmap.panTo( markerBounds.getCenter() ) );
          // infoWindow.open( map, marker );
          $item.trigger( 'marker' );
        } );
      }
    },

    // fitMarkerBounds: function() {  //console.trace();
    //   gmap || _private.init();
    //   gmap.fitBounds( markerBounds );
    // },

    placeMarker: function( i, rebound ) {
      let marker = markers[i];
      if ( !marker ) return;

      gmap || _private.init();
      marker.setMap( gmap );

      markerBounds || ( markerBounds = new google.maps.LatLngBounds() );
      markerBounds.extend( marker.getPosition() );

      if ( rebound ) {
        gmap.fitBounds( markerBounds );
        markerBounds = null;
      }
    },

    unplaceMarker: function( i ) {
      let marker = markers[i];
      marker && marker.setMap( null );
    },

    markerTrigger: function() {
      let i = $( this ).data( 'ord' ) - 1;
      google.maps.event.trigger( markers[i], 'click' );
    },

    route: function( origin, destination ) {
      gmap || _private.init()

      let request = {
        origin: origin,
        destination: destination,
        travelMode: google.maps.DirectionsTravelMode.DRIVING
      };

      directionsService.route( request, function( response, status ) {
        if ( status == google.maps.DirectionsStatus.OK ) {
          directionsDisplay.setDirections( response );
        }
      } );
    }
  };

  const _public = {
    init: _private.init,
    createMarker: _private.createMarker,
    placeMarker: _private.placeMarker,
    unplaceMarker: _private.unplaceMarker,
    // fitMarkerBounds: _private.fitMarkerBounds,
    markerTrigger: _private.markerTrigger,
    route: _private.route
  };

  return _public;
} )();

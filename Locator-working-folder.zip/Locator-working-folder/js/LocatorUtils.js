'use strict';

//---------------------------------------
// export const LocatorUtils = ( function() {
window.LocatorUtils = ( function() {
  const _private = {
      DAY: ( new Date() ).toLocaleString( 'en-us', { weekday: 'short' } ).replace( /^\W*/, '' ),
        // .replace() call needed because IE11 prepends a null character to output of .toLocaleString()
        // many Bothans died to bring us this information

      getLatLngLiteral: function( lat, lng ) {
        return {
          lat: parseFloat( lat ),
          lng: parseFloat( lng )
        };
      },

      getTitleCase: function( str ) {
        return str.toLowerCase().replace( /\b\w/g, m => m.toUpperCase() ).replace( /(?<=Ma?c)\w/, m => m.toUpperCase() );
      },

      getDetailUrl( type, locAddr ) {
        let url =
          `/${type}/${locAddr.state}/${locAddr.city}/${locAddr.zipCode.replace( /-\d+$/, '' )}/${locAddr.address1}`.replace( /\s+/g, '-' ).toLowerCase()
          .concat( location.search );

        return ( ( location.protocol == 'file:' ) ?
          `locator-detail-view.html?url=${url}` :
          url
        );
      }
  };

  const _public = {
      DAY: _private.DAY,
      getLatLngLiteral: _private.getLatLngLiteral,
      getTitleCase: _private.getTitleCase,
      getDetailUrl: _private.getDetailUrl
  };

  return _public;
} )();

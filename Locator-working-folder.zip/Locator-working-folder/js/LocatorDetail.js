'use strict';

//---------------------------------------
//export const LocatorDetail = ( function() {
window.LocatorDetail = ( function() {
  const _private = {
    init: function() {
      let place = JSON.parse( sessionStorage.getItem( 'locatorPlace' ) );
      let origin = ( place ? place.geometry.location : sessionStorage.getItem( 'locatorText' ) );

      let destination = LocatorUtils.getLatLngLiteral(      // TODO: once Rabi has coordinates embedded in page markup, use that instead of sessionStorage
        sessionStorage.getItem( 'locatorDestinationLat' ),
        sessionStorage.getItem( 'locatorDestinationLng' )
      );                                                    console.log( destination );

      LocatorMap.init();

      if ( origin ) {        console.log( origin );
        LocatorMap.route( origin, destination );
      }
      else {
        LocatorMap.placeMarker( destination.lat, destination.lng );
        LocatorMap.fitMarkerBounds();
      }
    }
  };

  const _public = {
    init: _private.init
  };

  return _public;
} )();
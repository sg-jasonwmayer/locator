'use strict';

//---------------------------------------
//export const Locator = ( function() {
window.Locator = ( function() {
   const _private = {
      //---------------------------------------
      ui: {
         init: function() {
            $( '.view-list-btn' ).click( _private.ui.viewToggle );
            $( '#btn-submit' ).click( _private.seeker.doLocationSearch );
            $( '.result-list-item-view' ).on( 'click', '.branch-heading', _private.mapper.markerTrigger );
         },

         viewToggle: function() {   // ES5-style function declaration needed for "this" keyword to work
            $( '.result-list-item-view' ).toggleClass( 'list-view-container' );
            $( '.list-item' ).toggleClass( 'list-view list-view-item' );
            $( '.map-view' ).toggle();
            $( this ).find( 'span' ).toggle();
         },

         handleError: function( err ) {
            console.error( 'WHAT WE HAVE HERE IS A FAILURE TO COMMUNICATE!', err );
         }
      },

      //---------------------------------------
      seeker: ( function() {
         let $autocomplete = $( '#autocomplete' );
         let autocomplete;

         function init() {
            autocomplete = new google.maps.places.Autocomplete( $autocomplete.get(0), {
               types: [ 'geocode' ],
               componentRestrictions: { 'country': 'us' }
            } );

            autocomplete.addListener( 'place_changed', handlePlaceChanged );
         }

         function handlePlaceChanged() {
            var place = autocomplete.getPlace();   console.log( 'place:', place );

            if ( place.geometry ) {
               // _private.mapper.init( place.geometry );
               doLocationSearch();
            }
            else {
               console.log( `No details available for input: ${place.name}` );
            }
         }

         function doLocationSearch() {    console.log( `Seeking locations near "${$autocomplete.val()}"` );
            $.get( {
               url: `https://cmsauthor-dev2.bbtnet.com/bin/locator/locations.json?address=${encodeURIComponent( $autocomplete.val() )}&locationType=BRANCH&returnBranchATMStatus=Y`,
               headers: {
                  'Authorization': 'Basic YWRtaW46YWRtaW4='    // once we've moved into AEM, we can drop auth header, and use relative url
               },
               dataType: 'json',
               success: handleLocationSearchResults,
               error: _private.ui.handleError
            } );
         }

         function handleLocationSearchResults( data ) {    //console.log( `${data.location.length} results`, data );
            if ( data.error ) {
               _private.ui.handleError( data.error );
               return;
            }

            _private.mapper.init();
            $( '.Search-navigation >div' ).eq( 0 ).text( `${data.location.length} Results` );

            $( '.result-list-item-view' ).empty().append(
               data.location.map( ( loc, i ) => {               console.log( loc );
                  let ord = i + 1;
                  _private.mapper.placeMarker( ord, loc );

                  let hoursToday = {};
                  [ 'driveThruHours', 'lobbyHours' ].forEach( timeTable => {  // TODO: MOVE THIS (AND ALL DATE/TIME FUNCTIONALITY) INTO LocatorUtils
                     loc[timeTable].find( entry => {
                        let entryDay, entryHours;
                        [ entryDay, entryHours ] = entry.split( /(\w{3}):/ ).slice( 1 );

                        if ( entryDay == LocatorUtils.DAY ) {
                           hoursToday[timeTable] = entryHours;
                           return true;
                        }
                     } );
                  } );

                  let replacements = [
                     loc.locationType,
                     LocatorUtils.getTitleCase( loc.locationName ),
                     LocatorUtils.getTitleCase( loc.locationAddress.address1 ),
                     LocatorUtils.getTitleCase( loc.locationAddress.city ),
                     loc.locationAddress.state,
                     loc.locationAddress.zipCode,
                     loc.phone.replace( /\)\s*/, ') ' ),
                     loc.locationDistance,
                     hoursToday.lobbyHours,
                     hoursToday.driveThruHours,
                     ord
                  ];

                  return $( '#cloners >.list-item' ).clone().attr( 'data-ord', ord ).html( ( i, was ) =>
                     was.replace( /\{(\d+)\}/g, ( m, p1 ) =>
                        replacements[p1] ? replacements[p1] : m
                     )
                  );
               } )
            )

            _private.mapper.fitMarkerBounds();
         }

         return {
            init: init,
            doLocationSearch: doLocationSearch
         };
      } )(),

      //---------------------------------------
      mapper: ( function() {
         let gmap, markerBounds, infoWindow;
         let markers = [];

         function init( geometry ) {
            // Clear previous markers, if any:
            markers.forEach( marker => marker.setMap( null ) );
            markers = [];

            // Ensure we have legit map and bounds objects:
            gmap = gmap || ( new google.maps.Map( $( '#map' ).get(0) ) );
            markerBounds = new google.maps.LatLngBounds();   // start with empty bounds, will expand as we add markers

            if ( geometry ) {    // iff geometry provided, set initial map view
               gmap.fitBounds( geometry.viewport );
            }

            return gmap;
         }

         function placeMarker( ord, loc ) {
            gmap || init();

            let pos = new google.maps.LatLng( loc.locationAddress.lat, loc.locationAddress.long );
            markerBounds.extend( pos );

            let marker = new google.maps.Marker( {
               position: pos,
               label: { text: `${ord}`, color: 'white' }
            } );

            markers.push( marker );
            marker.setMap( gmap );

            google.maps.event.addListener( marker, 'click', function() {
               infoWindow && infoWindow.close();
               infoWindow = new google.maps.InfoWindow( { content: $( `.list-item[data-ord=${ord}]` ).html() } );
               google.maps.event.addListener( infoWindow, 'closeclick', () => gmap.panTo( markerBounds.getCenter() ) );
               infoWindow.open( map, marker );
            } );
         }

         function fitMarkerBounds() {  console.trace();
            gmap || init();
            gmap.fitBounds( markerBounds );
         }

         function markerTrigger() {
            let i = $( this ).data( 'ord' ) - 1;
            google.maps.event.trigger( markers[i], 'click' );
         }

         return {
            init: init,
            placeMarker: placeMarker,
            fitMarkerBounds: fitMarkerBounds,
            markerTrigger: markerTrigger
         };
      } )()
   };

   const _public = {
      init: () => $( document ).ready( () => {
         _private.seeker.init();
         _private.ui.init();
      } )
   };

   return _public;
} )();

//---------------------------------------
// export const LocatorUtils = ( function() {
window.LocatorUtils = ( function() {
   const _private = {
      DAY: ( new Date() ).toLocaleString( 'en-us', { weekday: 'short' } ).replace( /^\W*/, '' ),
         // .replace() call needed because IE11 prepends a null character to output of .toLocaleString()
         // many Bothans died to bring us this information

      getTitleCase: function( str ) {
         return str.toLowerCase().replace( /\b\w/g, m => m.toUpperCase() ).replace( /(?<=Ma?c)\w/, m => m.toUpperCase() );
      }
   };

   const _public = {
      DAY: _private.DAY,
      getTitleCase: _private.getTitleCase,
   };

   return _public;
} )();

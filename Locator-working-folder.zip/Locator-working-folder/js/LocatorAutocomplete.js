'use strict';

//---------------------------------------
// export const LocatorAutocomplete = ( function() {
window.LocatorAutocomplete = ( function() {
  let $autocomplete, autocomplete, locatorPageFlag, geocoder;

  const _private = {
    AUTOCOMPLETE_OPTIONS: {
      types: [ 'geocode' ],
      componentRestrictions: { 'country': 'us' }
    },

    init: function( flag ) {    // TODO: let's initialize with a callback instead of boolean flag (and write a default one to do form submit)
      locatorPageFlag = flag;
      $autocomplete = $( '#autocomplete' );
      autocomplete = new google.maps.places.Autocomplete( $autocomplete.get(0), _private.AUTOCOMPLETE_OPTIONS );
      let $inputLocationButton = $( 'button.input-location-button' );

      autocomplete.addListener( 'place_changed', _private.handleAutoComplete );
      $( '#btn-submit' ).click( _private.handleSubmit );

      if ( navigator.geolocation ) {
        geocoder = new google.maps.Geocoder;
        $inputLocationButton.click( () => navigator.geolocation.getCurrentPosition( _private.handleGeoLocation ) );
      }
      else {
        $inputLocationButton.hide();
      }
    },

    handleAutoComplete: function( results, status ) {               //console.log( results )
      let place = results ? results[0] : autocomplete.getPlace();   //console.log( place );
      let ll = place.geometry.location;

      sessionStorage.setItem( 'locatorPlace', JSON.stringify( place ) );
      $autocomplete.val( ( i, was ) => was || place.formatted_address );

      _private.handoff( place.formatted_address, {
        lat: ll.lat(),
        long: ll.lng()
      } );
    },

    handleSubmit: function() {
      sessionStorage.removeItem( 'locatorPlace' );
      let text = $autocomplete.val();
      _private.handoff( text, { address: text } );
    },

    handleGeoLocation: function( position ) {
      let c = position.coords;
      let ll = LocatorUtils.getLatLngLiteral( c.latitude, c.longitude );

      $autocomplete.val( '' );
      geocoder.geocode( { location: ll }, _private.handleAutoComplete );
    },

    handoff: function( text, params ) {
      sessionStorage.setItem( 'locatorText', text );
      sessionStorage.setItem( 'locatorParams', JSON.stringify( params ) );

      if ( locatorPageFlag ) {   // we're on the Locator search page -- invoke search directly
        Locator.doLocationSearch( params );
      }
      else {                     // we're on some other page, using modal "find us" component -- store parameters, then go to Locator search page for processing
        $autocomplete.closest( 'form' ).submit();
      }
    },

    preFill: function( text ) {
      $autocomplete.val( text );
    }
  };

  const _public = {
    init: _private.init,  // currently invoked either as callback from Google library loader, or from Locator.init()
    preFill: _private.preFill
  };

  return _public;
} )();

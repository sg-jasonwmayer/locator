/*
IN PROTOTYPE, NOT YET IN REPO:
- util method to generate LatLngLiteral, given coordinates
- submit handler for "view details" to create sessionStorage item w/ destination coordinates (TEMP workaround, 'til detail component conveys them)

TODO:
- update w/ Srini's latest styling
- add auto-update on pan/zoom functionality (ref Srini's prototype)
- MAYBE: remove "page" and "seeker" wrappers?

- work w/ Rabi:
  - detail page needs reference to Google lib (Rabi working on this one)
  - location coordinates embedded somewhere in detail page, so we can grab them via jQuery

- update LocatorAutocomplete to take a callback on init, and to handle auto-replay based on sessionStorage
- add LocatorAutcomplete to detail page
- write callback for Autocomplete on detail page -- needs to update directions

- how to make service url and auth header dynamic?
*/
'use strict';

//---------------------------------------
//export const Locator = ( function() {
window.Locator = ( function() {
  let $resultListWrapper, $resultList;

  const _private = {
    SERVICE_URL: 'https://cmsauthor-dev2.bbtnet.com/bin/locator/locations.json',  // once we have page built on same AEM instance as the service layer, we can use relative url
    DEFAULT_BLOCK_SIZE: 1,   // TODO: update to 15, once we're done unit-testing

    //---------------------------------------
    page: ( function() {
      function init() {
        $resultListWrapper = $( '.result-list-item-view' );
        // $resultListWrapper.css( { height: '80vh', 'overflow-y': 'auto', position: 'relative' } );   // TEMP!!!!!!!
        // $resultListWrapper.on( 'click', '.branch-heading', LocatorMap.markerTrigger );   // delegated event handler!
        $resultListWrapper.on( 'marker', '.list-item', handleMarker );   // delegated event handler!
        _private.seeker.init();

        $resultListWrapper.on( 'submit', '.btn-view-details >form', function() {         // TEMP workaround, and delegated event handler!
          sessionStorage.setItem( 'locatorDestinationLat', $( this ).data( 'lat' ) );
          sessionStorage.setItem( 'locatorDestinationLng', $( this ).data( 'lng' ) );
        } );

        LocatorAutocomplete.preFill( sessionStorage.getItem( 'locatorText' ) );
        let params = JSON.parse( sessionStorage.getItem( 'locatorParams' ) );
        params && _private.seeker.doLocationSearch( params );

        // TODO: check sessionStorage for 'locatorPlace' key too -- maybe useful for analytics

        // TEMP workaround:
        ( location.protocol == 'file:../' ) && $( '.btn-view-details >a.hide' ).show();
      }

      function handleMarker() {
        let $me = $( this );
        $me.css( 'background-color', 'yellow' ).siblings().css( 'background-color', '' );

        let $wrapper = $me.offsetParent();
        // $wrapper.scrollTop( $wrapper.scrollTop() + $me.position().top );
        $wrapper.animate( { scrollTop: $wrapper.scrollTop() + $me.position().top } );
      }

      function handleError( err ) {
        console.error( 'WHAT WE HAVE HERE IS A FAILURE TO COMMUNICATE!', err );
      }

      return {
        init: init,
        handleError: handleError
      }
    })(),

    //---------------------------------------
    seeker: ( function() {
      let $loadMoreButton, $showLessButton;
      let blockSize, maxListIndex;
      let blocks = 1;

      function init() {
        blockSize = ( parseInt( $( 'SELECTOR-TBD' ).data() ) || _private.DEFAULT_BLOCK_SIZE );   // TODO: update with correct selector string, once we have it

        let $listControls = $( '#loadMore a' );
        $loadMoreButton = $listControls.first().click( () => reveal( 1 ) );
        $showLessButton = $listControls.last().click( () => reveal( -1 ) );
      }

      function doLocationSearch( params ) {
        Object.assign( params, {
          locationType: 'BRANCH',   // TODO: allow for dynamic filter criteria
          returnBranchATMStatus: 'Y'
        } );

        $.get( {
          url: `${_private.SERVICE_URL}?${Object.keys( params ).map( key => `${key}=${encodeURIComponent( params[key] )}` ).join( '&' )}`,
          headers: {
            'Authorization': 'Basic YWRtaW46YWRtaW4='    // once we have the service deployed to a publisher instance, we can drop the auth header
          },
          dataType: 'json',
          success: handleLocationSearchResults,
          error: _private.page.handleError
        } );
      }

      function handleLocationSearchResults( data ) {    console.log( `${data.location.length} RESULTS` );
        if ( data.error ) {
          _private.page.handleError( data.error );
          return;
        }

        let listIndex = 0;
        let alreadyGotOne = {};
        LocatorMap.init();
        $resultList && $resultList.remove();

        $resultListWrapper.prepend(
          data.location.flatMap( loc => {               //console.log( loc );
            let locAddr = loc.locationAddress;
            let detailUrl = LocatorUtils.getDetailUrl( loc.locationType, locAddr );

            if ( alreadyGotOne[ detailUrl ] ) {
              console.log( `DUPLICATE: ${detailUrl.replace( /^.*?\//, '/' )}` );
              return [];
            }

            alreadyGotOne[ detailUrl ] = true;

            let hoursToday = {};
            [ 'driveThruHours', 'lobbyHours' ].forEach( timeTable => {  // TODO: MOVE THIS (AND ALL DATE/TIME FUNCTIONALITY) INTO LocatorUtils
              if ( !loc[timeTable] ) return;

              loc[timeTable].find( entry => {
                let entryDay, entryHours;
                [ entryDay, entryHours ] = entry.split( /(\w{3}):/ ).slice( 1 );

                if ( entryDay == LocatorUtils.DAY ) {
                  hoursToday[timeTable] = entryHours;
                  return true;
                }
              } );
            } );

            let replacements = [
              loc.locationType,
              LocatorUtils.getTitleCase( loc.locationName ),
              LocatorUtils.getTitleCase( locAddr.address1 ),
              LocatorUtils.getTitleCase( locAddr.city ),
              locAddr.state,
              locAddr.zipCode,
              loc.phone.replace( /\)\s*/, ') ' ),
              loc.locationDistance,
              hoursToday.lobbyHours,
              hoursToday.driveThruHours,
              '',            // TODO: clean up
              detailUrl,
              locAddr.lat,   // TEMP workaround
              locAddr.long   // TEMP workaround
            ];

            let $item = $( '#cloners >.list-item' ).clone().html( ( i, was ) =>
              was.replace( /\{(\d+)\}/g, ( m, p1 ) =>
                replacements[p1] ? replacements[p1] : m
              )
            );

            LocatorMap.createMarker( locAddr.lat, locAddr.long, String( listIndex++ ), $item );
            return $item;
          } )
        )

        $resultList = $resultListWrapper.find( '.list-item' );
        $( '.Search-navigation >div' ).eq( 0 ).text( `${$resultList.length} Results` );
        maxListIndex = $resultList.length - 1;
        reveal( 0 );
      }

      function reveal( inc ) {
        blocks += inc;
        let ub = Math.min( blocks * blockSize - 1, maxListIndex );

        $resultList.each( function( i ) {
          let showMe = ( i <= ub );
          let rebound = ( i == ub );
          $( this ).toggle( showMe );
          showMe ? LocatorMap.placeMarker( i, rebound ) : LocatorMap.unplaceMarker( i );
        } );

        $loadMoreButton.toggle( ub < maxListIndex );
        $showLessButton.toggle( blocks > 1 );
      }

      return {
        init: init,
        doLocationSearch: doLocationSearch,
        reveal: reveal
      };
    } )(),
  };

  const _public = {
    init: function() {  // currently invoked as callback from Google library loader
      LocatorAutocomplete.init( true );
      _private.page.init();
    },

    doLocationSearch: _private.seeker.doLocationSearch
  };

  return _public;
} )();
